#include<iostream>
#include<string>
using namespace std;

class FoodItem{
private:
    string name;
    int calories;
    int gram_fats;
    int gram_carbohydrates;
    int gram_proteins;

public:
    FoodItem(string const & naam): name(naam), calories(0), gram_fats(0), gram_carbohydrates(0), gram_proteins(0) {}
    FoodItem(string const & naam, int cal): name(naam), calories(cal), gram_fats(0), gram_carbohydrates(0), gram_proteins(0) {}
    FoodItem(string const & naam, int cal, int fats, int carbs, int proteins): name(naam), calories(cal), gram_fats(fats), gram_carbohydrates(carbs), gram_proteins(proteins) {}

    string getname() {
        return name;
    }
    int getcalorie() {
        return calories;
    }
    int getfats() {
        return gram_fats;
    }
    int getcarbs() {
        return gram_carbohydrates;
    }
    int getproteins() {
        return gram_proteins;
    }

    void setname(string const &naam) {
        name = naam;
    }
    void setcalories(int cal) {
        if (cal >= 0) {
            calories = cal;
        }
        else {
            cout << " Calories cannot be negative." << endl;
        }
    }
    void setfats(int fats) {
        if (fats >= 0) {
            gram_fats = fats;
        }
        else {
            cout << " Fat cannot be negative." << endl;
        }

    }
    void setcarbs(int carbs) {
        if (carbs >= 0) {
            gram_carbohydrates = carbs;
        }
        else {
            cout << " Carbs cannot be negative." << endl;
        }

    }
    void setproteins(int proteins) {
        if (proteins >= 0) {
            gram_proteins = proteins;
        }
        else {
            cout << " Proteins cannot be negative." << endl;
        }

    }

    friend int calculateCalories(int carbs, int proteins, int fats);
};

int calculateCalories(int carbs, int proteins, int fats) {
    return (4 * carbs) + (4 * proteins) + (9 * fats);
}

int main() {
    string name;
    int gram_proteins;
    int gram_carbohydrates;
    int gram_fats;
    int calories; // Declaration of calories variable

    do {
        cout << "Enter name of item (type exit to quit): ";
        getline(cin, name);
        if (name == "exit") {
            break;
        }
        else {
            cout << "Enter calories: ";
            cin >> calories;
            cout << "Enter proteins: ";
            cin >> gram_proteins;

            cout << "Enter carbs: ";
            cin >> gram_carbohydrates;
            cout << "Enter fats: ";
            cin >> gram_fats;

            FoodItem f1(name);
            f1.setproteins(gram_proteins);
            f1.setcarbs(gram_carbohydrates);
            f1.setfats(gram_fats);

            int calories = calculateCalories(f1.getcarbs(), f1.getproteins(), f1.getfats());

            cout << "DETAILED ITEMS:" << endl;
            cout << "NAME: " << f1.getname() << endl;
            cout << "Calories: " << f1.getcalorie() << endl;
            cout << "Proteins: " << f1.getproteins() << endl;
            cout << "Fats: " << f1.getfats() << endl;
            cout << "Carbs: " << f1.getcarbs() << endl;
        }
    } while (true);

    return 0;
}
