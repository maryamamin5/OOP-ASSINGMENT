#include<iostream>
#include<string>
using namespace std;
class Book{

	string title;
	string nameofauthor;
	string genreofbook;
	bool availability_status;
	public:
		Book(const string &btitle,const string &bauthor,const string &bgenre,bool availability):title(btitle),nameofauthor(bauthor),genreofbook(bgenre),availability_status(availability){
		}
		string gettitle(){
			return title;
			
		}
		string getauthor(){
			return nameofauthor;
			
		}
		string getgenre(){
			return genreofbook;
			
		}
		bool getavailability(){
			return availability_status;
			
		}
		void settitle(const string &btitle){
			title=btitle;
		
		}
		void setauthor(const string &bauthor){
			nameofauthor=bauthor;
		
		}
		void setgenre(const string &bgenre){
			genreofbook=bgenre;
		
		}
		bool setavailability(bool availability ){
			availability_status=availability;
		
		}
		
		
};  
class Library{
	Book** book;
	int count;
	int num_books;
	
	public:
	Library(int num=5):num_books(num),count(0){
		book=new Book*[num_books];
	}
	~Library(){
		for(int i=0;i<count;i++){
			delete book[i];
		}
		delete[] book;
	}
	void AddBooks(const string &btitle,const string &bauthor,const string &bgenre,bool availability)
	{
		if(count>=num_books){
			cout<<"limit exceed"<<endl;
		}
		book[count++]=new Book( btitle, bauthor, bgenre, availability);
	}
	
	void availableGenre(string const &bgenre){
		cout<<"Enter the genre to display available books :"<<bgenre<<endl;
		for (int i=0;i<count;i++) {
            if (book[i]->getgenre() == bgenre && book[i]->getavailability()) {
                cout << "Enter book title: " << book[i]->gettitle()<<endl;
			   cout<< "Enter name of author: " << book[i]->getauthor() << endl;
			   
            }
            
		
	}
}
};
int main(){
	Library l1;
	char yesorno;
	do{
			string title;
        	string nameofauthor;
	        string genreofbook;
        	bool availability_status;
        	cout<<"Enter title of book:";
        	getline(cin,title);
        	cout<<"Enter name of author:";
        	getline(cin,nameofauthor);
        	cout<<"Enter genre of book:";
        	getline(cin,genreofbook);
        	cout<<"Is the book available(1/0)?: ";
        	cin>>availability_status;
        	l1.AddBooks(title,nameofauthor,genreofbook,availability_status);
        	cout<<"Do you want to add another book?(yes/no)";
        	cin>>yesorno;
		
	}
	while(yesorno=='y'|| yesorno=='Y');
	string specific_genre;
	cout<<"Enter the genre to display available books:"<<endl;
	getline(cin,specific_genre);
	l1.availableGenre(specific_genre);
	return 0;
}
