#include <iostream>
#include <string>

using namespace std;

class AutonomousVehicle{
    
protected:
    int id;
    int battery_capacity;
    string vehicleType;
    int maxSpeed;

public:
    AutonomousVehicle(){};
    AutonomousVehicle(int id, string vehicleType, int battery_capacity, int maxSpeed) : id(id), vehicleType(vehicleType), battery_capacity(battery_capacity), maxSpeed(maxSpeed){};

    // shallow copy
     AutonomousVehicle(const AutonomousVehicle &other)
      {
          cout << "shallow copy" << endl;
         id = other.id;
          vehicleType = other.vehicleType;
         battery_capacity = other.battery_capacity;
         maxSpeed = other.maxSpeed;
     }

     //deep copy
   AutonomousVehicle(const AutonomousVehicle &vehical)
     {
        id = *(new int(vehical.id));
        vehicleType = *(new string(vehical.vehicleType));
        battery_capacity = *(new int(vehical.battery_capacity));
        maxSpeed = *(new int(vehical.maxSpeed));
    }
};

class Sedan : protected AutonomousVehicle
{
public:
    Sedan(){};
    Sedan(int id, int battery_capacity, int maxSpeed)
        : AutonomousVehicle(id, "Sedan", battery_capacity, maxSpeed){};

    // deep copy
    Sedan(const Sedan &vehical)
    {
        id = *(new int(vehical.id));
        vehicleType = *(new string(vehical.vehicleType));
        battery_capacity = *(new int(vehical.battery_capacity));
        maxSpeed = *(new int(vehical.maxSpeed));
    }

    // getter functios
    int get_id() { return id; }
    string get_vehicleType() { return vehicleType; }
    int get_batteryCapacity() { return battery_capacity; }
    int get_maximumSpeed() { return maxSpeed; }

    // setters functions
    void set_id(int id) { this->id = id; }
    void set_vehicleType(string vehicleType) { this->vehicleType = vehicleType; }
    void set_batteryCapacity(int batteryCapacity) { this->battery_capacity = batteryCapacity; }
    void set_maximumSpeed(int maximumSpeed) { this->maxSpeed = maximumSpeed; }

    void displayValues()
    {
        cout << "Vehicle Id = " << id << "\t\t\t" << &id << endl;
        cout << "Vehicle Type = " + vehicleType + "\t\t" << &vehicleType << endl;
        cout << "Vehicle Battery Capacity = " << battery_capacity << "A\t" << &battery_capacity << endl;
        cout << "Vehicle Maximum speed = " << maxSpeed << " m/s\t" << &maxSpeed << endl;
        cout << endl;
    };
};

class Suv : protected AutonomousVehicle
{
public:
    Suv(){};
    Suv(int id, int battery_capacity, int maxSpeed)
        : AutonomousVehicle(id, "Suv", battery_capacity, maxSpeed){};

    // getter functios
    int get_id() { return id; }
    string get_vehicleType() { return vehicleType; }
    int get_batteryCapacity() { return battery_capacity; }
    int get_maximumSpeed() { return maxSpeed; }

    // setters functions
    void set_id(int id) { this->id = id; }
    void set_vehicleType(string vehicleType) { this->vehicleType = vehicleType; }
    void set_batteryCapacity(int batteryCapacity) { this->battery_capacity = batteryCapacity; }
    void set_maximumSpeed(int maximumSpeed) { this->maxSpeed = maximumSpeed; }

    void displayValues()
    {
        cout << "Vehicle Id = " << id << "\t\t\t" << &id << endl;
        cout << "Vehicle Type = " + vehicleType + "\t\t" << &vehicleType << endl;
        cout << "Vehicle Battery Capacity = " << battery_capacity << "A\t" << &battery_capacity << endl;
        cout << "Vehicle Maximum speed = " << maxSpeed << " m/s\t" << &maxSpeed << endl;
        cout << endl;
    };
};

int main()
{

    Sedan sedan(1, 200, 200);
    cout << "sedan" << endl;
    sedan.displayValues();

    Sedan *hybridSedan;
    cout << "Creating new hybrid sedan with Shallow Copy " << endl << endl;
    hybridSedan = &sedan; //  shallow copy
    cout << "Creating new electric sedan with Deep Copy " << endl<< endl;
    Sedan electricSedan(sedan); // deep copy constructor

    cout << "hybrid sedan" << endl<< endl;
    hybridSedan->displayValues();

    cout << "electric sedan" << endl;
    electricSedan.displayValues();

    cout << "changing the maximum speed of general Sedan" << endl<< endl;

    sedan.set_maximumSpeed(300);

    cout << "sedan" << endl<< endl;
    sedan.displayValues();

    cout << "hybridSedan sedan" << endl << endl;
    hybridSedan->displayValues();

    cout << "electric sedan" << endl<< endl;
    electricSedan.displayValues();

    return 0;
}