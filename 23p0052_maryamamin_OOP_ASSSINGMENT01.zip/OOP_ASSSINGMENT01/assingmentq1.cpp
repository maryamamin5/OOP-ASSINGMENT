#include <iostream>
#include <string>

using namespace std;

const int maximum_items = 100; // Maximum number of items in the inventory

struct Itemsofinventory {
    int item_id;
    string item_name;
    int quantity;
    string category;
};

class Managementofinventory {
private:
    Itemsofinventory inventory[maximum_items];
    int itemcount;

public:
    Managementofinventory() : itemcount(0) {}

    void add_item(int i_id, const string& i_name, int quantity, const string& category) {
        if (itemcount < maximum_items) {
            inventory[itemcount++] = {i_id, i_name, quantity, category};
            cout << "Item added successfully." << endl;
        } else {
            cout << "Sorry! We cannot add more items to the inventory." << endl;
        }
    }

    void updateditems(int i_id, int new_quantity) {
        for (int i = 0; i < itemcount; ++i) {
            if (inventory[i].item_id == i_id) {
                inventory[i].quantity = new_quantity;
                cout << "Quantity updated successfully." << endl;
                return;
            }
        }
        cout << "Item not found." << endl;
    }

    Itemsofinventory getItemById(int itemId) {
        for (int i = 0; i < itemcount; ++i) {
            if (inventory[i].item_id == itemId) {
                return inventory[i];
            }
        }
        cout << "Item not found." << endl;
        return Itemsofinventory {}; // Returning an empty item
    }

    void displaytotalcategory(const string& category) {
        int totalCount = 0;
        for (int i = 0; i < itemcount; ++i) {
            if (inventory[i].category == category) {
                totalCount += inventory[i].quantity;
            }
        }
        cout << "Total count of items in category " << category << ": " << totalCount << endl;
    }

    void displayitemdetail() {
        cout << "Inventory Details:" << endl;
        for (int i = 0; i < itemcount; ++i) {
            cout << "Item ID: " << inventory[i].item_id << ", Name: " << inventory[i].item_name
                 << ", Quantity: " << inventory[i].quantity << ", Category: " << inventory[i].category << endl;
        }
    }

    void displaytotalitem() {
        int totalCount = 0;
        for (int i = 0; i < itemcount; ++i) {
            totalCount += inventory[i].quantity;
        }
        cout << "Total count of items in inventory: " << totalCount << endl;
    }

    void displaytotalitembycategory() {
        cout << "Total count of items in each category:" << endl;
        for (int i = 0; i < itemcount; ++i) {
            string currentCategory = inventory[i].category;
            int categoryCount = 0;
            for (int j = 0; j < itemcount; ++j) {
                if (inventory[j].category == currentCategory) {
                    categoryCount += inventory[j].quantity;
                }
            }
            cout << currentCategory << ": " << categoryCount << endl;
        }
    }
};

int main() {
    Managementofinventory manager;

    char choice;
    do {
        cout << "choose option to enter in inventory store:" << endl;
        cout << "1.add item" << endl;
        cout << "2.update quantity of item" << endl;
        cout << "3.get item details by id of item" << endl;
        cout << "4.display total count of items in each category" << endl;
        cout << "5.display total count of all items" << endl;
        cout << "6.display all item details of item" << endl;
        cout << "7.exit" << endl;
        cout << "enter your choice: ";
        cin >> choice;
        cout << endl;

        switch (choice) {
            case '1': {
                int itemId, quantity;
                string itemName, category;
                cout <<"Enter item id: ";
                cin >> itemId;
                cout <<"0Enter item name: ";
                cin >> itemName;
                cout << "Enter item quantity: ";
                cin >> quantity;
                cout << "Enter item category: ";
                cin >> category;
                manager.add_item(itemId, itemName, quantity, category);
                break;
            }
            case '2': {
                int itemId, quantity;
                cout << "Enter item ID: ";
                cin >> itemId;
                cout << "Enter new quantity: ";
                cin >> quantity;
                manager.updateditems(itemId, quantity);
                break;
            }
            case '3': {
                int itemId;
                cout << "Enter item ID: ";
                cin >> itemId;
                Itemsofinventory item = manager.getItemById(itemId);
                cout << "Item details:" << endl;
                cout << "Item ID: " << item.item_id << ", Name: " << item.item_name
                     << ", Quantity: " << item.quantity << ", Category: " << item.category << endl;
                break;
            }
            case '4':
                manager.displaytotalitembycategory();
                break;
            case '5':
                manager.displaytotalitem();
                break;
            case '6':
                manager.displayitemdetail();
                break;
            case '7':
                cout << "Exit..." << endl;
                break;
            default:
                cout << "Invalid choice." << endl;
        }

        cout << endl;
    } while (choice != '7');

    return 0;
}
