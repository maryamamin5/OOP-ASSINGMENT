#include <iostream>
#include <string>

using namespace std;

class Robot
{

private:
    int id;
    string type;
    string powerSource;
    int maximumSpeed;
    double weight;

public:
    Robot(){};
    Robot(int id, string type, string powerSource, int maximum_Speed, double weight) : id(id), type(type), powerSource(powerSource), maximumSpeed(maximumSpeed), weight(weight){};
    // distructor
    ~Robot() {}

    // setters
    void set_id(int id) { this->id = id; };
    void set_type(string type) { this->type = type; };
    void set_powerSource(string powerSource) { this->powerSource = powerSource; };
    void set_maximum_Speed(int maximum_Speed) { this->maximumSpeed = maximum_Speed; };
    void set_weight(double weight) { this->weight = weight; };

    // getters

    Robot(const Robot &robot)
        : id(robot.id), type(robot.type), powerSource(robot.powerSource), maximumSpeed(robot.maximumSpeed), weight(robot.weight) {}

    // Deep Copy Constructor
    Robot(const Robot &robot, int deep) : maximumSpeed(robot.maximumSpeed)
    {
        id = robot.id;
        // maximumSpeed = robot.maximumSpeed;
        type = robot.type;
        powerSource = robot.powerSource;
        weight = robot.weight;
    }

    void displayAtributes()
    {
        cout << "Robot id : " << id << "\t\t" << &id << endl;
        cout << "Type : " << type << "\t\t" << &type << endl;
        cout << "Power source : " << powerSource << "\t" << &powerSource << ")" << endl;
        cout << "Max speed : " << maximumSpeed << "m/s\t" << &maximumSpeed << ")" << endl;
        cout << "Weight : " << weight << "kg\t\t" << &weight << endl
             << endl;
    };
};

Robot *shallowCopy(Robot &a)
{
    Robot *b(&a);
    return b;
}

Robot *deepCopy(Robot &a)
{
    Robot *b = new Robot(a);
    return b;
}

int main()
{

    Robot *robots[3];
    Robot originalObject(1, "humanoid", "fuel", 122, 1.11);

    robots[0] = &originalObject;
    robots[0]->displayAtributes();

    cout << "shallow copy " << endl;
    robots[1] = shallowCopy(*robots[0]);
    robots[1]->displayAtributes();

    cout << "deep copy " << endl;
    robots[2] = deepCopy(*robots[0]);
    robots[2]->displayAtributes();

    cout << "changing the value of origianal first object" << endl;

    robots[0]->set_id(1111);
    robots[0]->set_powerSource("industrial");
    robots[0]->set_type("solar");
    robots[0]->set_maximum_Speed(1111);
    robots[0]->set_weight(9.200);

    cout << "-----------------------------------------------------------------------" << endl;
    robots[0]->displayAtributes();
    cout << "shallow copy values also changed" << endl;

    robots[1]->displayAtributes();

    cout << "deep copy values not changed" << endl;

    robots[2]->displayAtributes();

    return 0;
}