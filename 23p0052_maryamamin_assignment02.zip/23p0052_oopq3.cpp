#include <iostream>
#include <array>
using namespace std;

class GameBoard {
protected:
    const array<array<int, 4>, 4> dimensions; 
public:
void display() const {
        cout << "Base GameBoard Display:" << endl;
        for (const auto& row : dimensions) {
            for (const auto& cell : row) {
                cout << cell << " ";
            }
            cout << endl;
        }
    }
     GameBoard() : dimensions({{ {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0} }}) {}

    const array<array<int, 4>, 4>& getDimensions(){
        return dimensions;
    }
};

class PuzzleBoard : public GameBoard {
public:
    PuzzleBoard() {}

    void display() {
        cout << "PuzzleBoard Display:" << endl;
        auto modifiableBoard = getDimensions();
        modifiableBoard[0][0] = 2;
        for (const auto& row : modifiableBoard) {
            for (const auto& cell : row) {
                cout << cell << " ";
            }
            cout << endl;
        }
    }
};

class BattleBoard : public GameBoard {
public:
    BattleBoard() {}

    void display(){
        cout << "BattleBoard Display:" << endl;
        auto modifiableBoard = getDimensions();
        modifiableBoard[1][1] = 3;
        for (const auto& row : modifiableBoard) {
            for (const auto& cell : row) {
                cout << cell << " ";
            }
            cout << endl;
        }
    }
};

int main() {
    GameBoard baseBoard;
    baseBoard.display(); 
    PuzzleBoard puzzleBoard;
    puzzleBoard.display();
    BattleBoard battleBoard;
    battleBoard.display();

    return 0;
}
/*
1. Corrected the syntax of the for loop to properly loop through the arrays.
2.  Resolved the problem of having two variables with the same name in puzzleboard and battleboard by using the base class's dimensions array directly
3. made the getdimension function and use protected modifier instead of public
*/

