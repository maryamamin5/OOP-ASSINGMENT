#include <iostream>
#include <string>
using namespace std;
class UAV{
public:
    string name;
  float  weight;
    float maxaltitude;
    virtual void display() {
        cout << "I am a UAV" << endl;
        cout << "My name is: " << name << endl;
        cout << "My weight is: " << weight << " kg" << endl;
        cout << "My altitude is: " << maxaltitude << " ft" << endl;
    }
     virtual void takeOff(){
        cout <<"Taking off"<< endl;
    }

    virtual void land(){
        cout <<"Landing"<< endl;
    }
};

class SurveillanceUAV:virtual public UAV {
public:
    int zoomlevel;
    float recordingcapacity;
    bool nightvision;

    void recordVideo(){
        cout <<"Recording video"<< endl;
    }

    virtual void display(){
        cout <<"I am a Surveillance UAV"<< endl;
        UAV::display();
        cout << "My zoom level is: " << zoomlevel << " x" << endl;
        cout << "My recording capacity is: " << recordingcapacity <<"GB"<< endl;
        if(nightvision)
        cout<<"I have night vision"<< endl;
    }
};
class CargoDeliveryUAV:virtual public UAV {
public:
    float cargoArea;
    void deliverCargo(){
        cout<<"Delivering cargo"<< endl;
    }
virtual void display(){
        cout << "I am a Cargo Delivery UAV" << endl;
        UAV::display();
        cout << "My cargo area is: " << cargoArea << endl;
    }
};
class MultiPurposeUAV:public SurveillanceUAV,public CargoDeliveryUAV {
public:
    float solarPanelEfficiency;
     void deliverCargoWithSurveillance() {
        takeOff();
        recordVideo();
        land();
        deliverCargo();
    }
 virtual void display(){
        cout << "I am a Multi Purpose UAV" << endl;
        UAV::display();
        cout <<"My zoom level is: " << zoomlevel <<" x"<< endl;
        cout <<"My recording capacity is: "<<recordingcapacity <<"GB"<< endl;
        if(nightvision)
        cout <<"I have night vision" <<endl;
        cout <<"My cargo area is: "<<cargoArea<<endl;
        cout <<"My solar panel efficiency is: " <<solarPanelEfficiency<<endl;
    }
};

int main() {
   
    SurveillanceUAV surveillanceUAV;
    surveillanceUAV.name = "Surveillance drone";
    surveillanceUAV.weight = 16.700;
    surveillanceUAV.maxaltitude = 1000.00;
    surveillanceUAV.zoomlevel = 20.00;
    surveillanceUAV.recordingcapacity = 3.00;
    surveillanceUAV.nightvision = true;
    CargoDeliveryUAV cargoUAV;
    cargoUAV.name = "Multi purpose drone";
    cargoUAV.weight = 14.5;
    cargoUAV.maxaltitude = 3000.000;
    cargoUAV.cargoArea = 40.000;
    MultiPurposeUAV multiUAV;
    multiUAV.name = "Multi purpose drone";
    multiUAV.weight = 10.400;
    multiUAV.maxaltitude = 2000.000;
    multiUAV.zoomlevel = 20.000;
    multiUAV.recordingcapacity = 5.000;
    multiUAV.nightvision = true;
    multiUAV.cargoArea = 5.000;
    multiUAV.solarPanelEfficiency = 5.000;
    surveillanceUAV.display();
    cout << endl;
    cargoUAV.display();
    cout << endl;
     multiUAV.display();
    cout << endl;
    cout << "I am going to deliver a cargo along with surveillance" << endl;
    multiUAV.deliverCargoWithSurveillance();

    return 0;
}
