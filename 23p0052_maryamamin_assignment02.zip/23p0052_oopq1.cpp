#include<iostream>
#include<string>
using namespace std;

class ReadingMaterial{
	public:
		string title;
		string author;
		ReadingMaterial(string tit,string auth):title(tit),author(auth){}
		void display()
		{
			cout<<"The title is"<<title<<endl<<"The name of the author is:"<<author<<endl;
		}
};

class Book:virtual public ReadingMaterial{
	public:
		int pageCount;
		Book(string tit,string auth,int count):ReadingMaterial(tit,auth),pageCount(count){}
		void readPage(int num)
		{
			cout<<"Number of pages read:"<<num<<endl;
		}
		void calculateReadTime()
		{
			int time=static_cast<double>(pageCount)/2.0;
			cout<<"Total time to read the book : "<<time<<"minute"<<endl<<endl;	
		}
};

class Magazine:virtual public ReadingMaterial{
	public:
		int pageCount;
		Magazine(string tit,string auth, int count):ReadingMaterial(tit,auth),pageCount(count){}
		void browseSection(string section)
		{
			cout<<"Name of the browsing section is:"<<section<<endl<<endl;
		}
		void calculatePageTurnSpeed()
		{
			int speed=static_cast<double>(pageCount);
			cout<<"Page turn speed is "<<"one page per second so the total time to turn pages will be "<<speed<<"sec"<<endl<<endl;
		}
};

class ReferenceMaterial:public Book,public Magazine{
	public:
		ReferenceMaterial(string tit,string auth,int count):ReadingMaterial(tit,auth),Book(tit,auth,count),Magazine(tit,auth,count){}
};

int main()
{
	Book book("The Power of Habit", "Charles Duhigg", 371);
	Magazine magazine("The Alchemist", "Paulo Coelho", 208);
	ReferenceMaterial material("Sapiens: A Brief History of Humankind", "Yuval Noah Harari", 443);
	
	book.display();
	book.readPage(50);
	book.calculateReadTime();
	cout<<endl;
	magazine.display();
	magazine.browseSection("History");
	magazine.calculatePageTurnSpeed();
	cout<<endl;
	material.display();
	material.readPage(10);
	material.calculateReadTime();
	material.calculatePageTurnSpeed();
	material.browseSection("Sharks");	
	return 0;
}

